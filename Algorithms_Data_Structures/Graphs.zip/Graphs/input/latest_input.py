input_data = {
    "links_data": [{
        "target": "standard_verify(data_import)",
        "source": "standard_import_file(data_import)"
    },
        {
            "target": "udf_verify(data_import)",
            "source": "udf_import_file(data_import)"
        },
        {
            "target": "both_verify(data_import)",
            "source": "both_import_file(data_import)"
        },
        {
            "target": "udf_populate_dynamic_data_for_non_ssa_fields(data_import)",
            "source": "include_only_udf_fields(data_import)"
        }, {
            "target": "standard_populate_dynamic_data_for_non_ssa_fields(data_import)",
            "source": "include_only_standard_fields(data_import)"
        }, {
            "target": "data_import()",
            "source": "Fluent()"
        }, {
            "target": "project()",
            "source": "Fluent()"
        }, {
            "target": "create_for_entity(data_import)",
            "source": "data_import()"
        }, {
            "target": "set_title(project)",
            "source": "project()"
        }, {
            "target": "set_description(project)",
            "source": "project()"
        }, {
            "target": "where_field_mapping_is(data_import)",
            "source": "create_for_entity(data_import)"
        }, {
            "target": "title_verify(project)",
            "source": "set_title(project)"
        }, {
            "target": "desc_verify(project)",
            "source": "set_description(project)"
        }, {
            "target": "include_both_standard_and_udf_fields(data_import)",
            "source": "where_field_mapping_is(data_import)"
        }, {
            "target": "include_only_standard_fields(data_import)",
            "source": "where_field_mapping_is(data_import)"
        }, {
            "target": "include_only_udf_fields(data_import)",
            "source": "where_field_mapping_is(data_import)"
        }, {
            "target": "both_populate_dynamic_data_for_non_ssa_fields(data_import)",
            "source": "include_both_standard_and_udf_fields(data_import)"
        }, {
            "target": "standard_import_file(data_import)",
            "source": "standard_populate_dynamic_data_for_non_ssa_fields(data_import)"
        },
        {
            "target": "udf_import_file(data_import)",
            "source": "udf_populate_dynamic_data_for_non_ssa_fields(data_import)"
        },
        {
            "target": "both_import_file(data_import)",
            "source": "both_populate_dynamic_data_for_non_ssa_fields(data_import)"
        }
    ],
    "nodes_data": [{
        "label": "import_file",
        "id": "standard_import_file(data_import)",
        "sequence": 1,
        "type": ["Atom"]
    }, {
        "label": "include_only_udf_fields",
        "id": "include_only_udf_fields(data_import)",
        "sequence": 2,
        "type": ["Atom"]
    }, {
        "label": "include_only_standard_fields",
        "id": "include_only_standard_fields(data_import)",
        "sequence": 3,
        "type": ["Atom"]
    }, {
        "label": "verify",
        "id": "standard_verify(data_import)",
        "sequence": 4,
        "type": ["Atom"]
    }, {
        "label": "verify",
        "id": "title_verify(project)",
        "sequence": 5,
        "type": ["Atom"]
    }, {
        "label": "Fluent",
        "id": "Fluent()",
        "sequence": 76,
        "type": ["Entity"]
    }, {
        "label": "data_import",
        "id": "data_import()",
        "sequence": 77,
        "type": ["Entity"]
    }, {
        "label": "project",
        "id": "project()",
        "sequence": 78,
        "type": ["Entity"]
    }, {
        "label": "create_for_entity",
        "id": "create_for_entity(data_import)",
        "sequence": 79,
        "type": ["Atom"],
        "args": ["PROGRAM"]
    }, {
        "label": "set_title",
        "id": "set_title(project)",
        "sequence": 80,
        "type": ["Atom"],
        "args": ["project_title"]
    }, {
        "label": "set_description",
        "id": "set_description(project)",
        "sequence": 81,
        "type": ["Atom"],
        "args": ["this_is_my_description"]
    }, {
        "label": "where_field_mapping_is",
        "id": "where_field_mapping_is(data_import)",
        "sequence": 82,
        "type": ["Atom"],
        "args": ["SAME"]
    }, {
        "label": "include_both_standard_and_udf_fields",
        "id": "include_both_standard_and_udf_fields(data_import)",
        "sequence": 83,
        "type": ["Atom"]
    }, {
        "label": "populate_dynamic_data_for_non_ssa_fields",
        "id": "standard_populate_dynamic_data_for_non_ssa_fields(data_import)",
        "sequence": 95,
        "type": ["Atom"]
    },
        {
            "label": "populate_dynamic_data_for_non_ssa_fields",
            "id": "udf_populate_dynamic_data_for_non_ssa_fields(data_import)",
            "sequence": 96,
            "type": ["Atom"]
        },
        {
            "label": "populate_dynamic_data_for_non_ssa_fields",
            "id": "both_populate_dynamic_data_for_non_ssa_fields(data_import)",
            "sequence": 97,
            "type": ["Atom"]
        },
        {
            "label": "import_file",
            "id": "udf_import_file(data_import)",
            "sequence": 98,
            "type": ["Atom"]
        },
        {
            "label": "import_file",
            "id": "both_import_file(data_import)",
            "sequence": 99,
            "type": ["Atom"]
        },
        {
            "label": "verify",
            "id": "udf_verify(data_import)",
            "sequence": 100,
            "type": ["Atom"]
        },
        {
            "label": "verify",
            "id": "both_verify(data_import)",
            "sequence": 101,
            "type": ["Atom"]
        },
        {
            "label": "verify",
            "id": "desc_verify(project)",
            "sequence": 102,
            "type": ["Atom"]
        }

    ]
}
