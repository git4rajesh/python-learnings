class D3JsonFormatter:
    def __init__(self, lst_valid_paths, nodes_data):
        self.lst_valid_paths = lst_valid_paths
        self.nodes_data = nodes_data

    def convert_lst_d3_json(self):
        test_case_d3_json_graph = {}
        index = 0
        for testcase in self.lst_valid_paths:
            dct_data = {}
            new_links_data = self.populate_links_data(testcase)
            dct_data['links_data'] = new_links_data
            new_nodes_data = self.populate_nodes_data(testcase)
            dct_data['nodes_data'] = new_nodes_data
            index = index + 1
            key_name = 'G' + str(index)
            test_case_d3_json_graph[key_name] = dct_data
        return test_case_d3_json_graph

    def get_master_graph(self):
        test_graphs = self.convert_lst_d3_json()
        lst_links_data, lst_nodes_data = self.get_lst_nodes_links(test_graphs)
        set_links_data, set_nodes_data = self.get_unique_nodes_links(lst_links_data, lst_nodes_data)
        lst_link, lst_nodes = self.convert_json_dumps_to_dict(set_links_data, set_nodes_data)
        dct_master_graph = self.construct_master_graph(lst_link, lst_nodes)
        return dct_master_graph

    def populate_nodes_data(self, testcase):
        new_nodes_data = []
        for atom in testcase:
            for node in self.nodes_data:
                if atom == node['id']:
                    new_nodes_data.append(node)
                    break
        return new_nodes_data

    def populate_links_data(self, testcase):
        lst_d3_json = []
        for index, value in enumerate(testcase):
            if index <= len(testcase) - 2:
                d3_json = {}
                d3_json['source'] = value
                d3_json['target'] = testcase[index + 1]
                # d3_json['strength'] = 1
                lst_d3_json.append(d3_json)
        return lst_d3_json

    def get_lst_nodes_links(self, test_graphs):
        lst_nodes_data = []
        lst_links_data = []
        for test in test_graphs:
            node_data = test_graphs[test]['nodes_data']
            link_data = test_graphs[test]['links_data']
            lst_nodes_data.extend(node_data)
            lst_links_data.extend(link_data)
        return lst_links_data, lst_nodes_data

    def get_unique_nodes_links(self, lst_links_data, lst_nodes_data):
        import json
        set_nodes_data = set()
        set_links_data = set()
        for item in lst_nodes_data:
            set_nodes_data.add(json.dumps(item, sort_keys=True))
        for item in lst_links_data:
            set_links_data.add(json.dumps(item, sort_keys=True))
        return set_links_data, set_nodes_data

    def convert_json_dumps_to_dict(self, set_links_data, set_nodes_data):
        import ast
        lst_nodes_data = list(set_nodes_data)
        lst_links_data = list(set_links_data)
        lst_link = []
        lst_nodes = []
        for item in lst_links_data:
            lst_link.append(ast.literal_eval(item))
        for item in lst_nodes_data:
            lst_nodes.append(ast.literal_eval(item))

        return lst_link, lst_nodes

    def construct_master_graph(self, lst_link, lst_nodes):
        dct_master_graph = {}
        dct_data = {}
        dct_data['nodes_data'] = lst_nodes
        dct_data['links_data'] = lst_link
        dct_master_graph['graph_data'] = dct_data
        return dct_master_graph
