from itertools import chain, combinations, product


class CombinationGen:
    def __init__(self, yaml_n_wise_dct):
        self.yaml_n_wise_dct = yaml_n_wise_dct

    def generate_combination(self, n_wise):
        lst_merged_yaml_vals = []
        for item in self.yaml_n_wise_dct:
            lst_merged_yaml_vals += self.yaml_n_wise_dct[item]

        lst_full_combination = list(combinations(lst_merged_yaml_vals, n_wise))
        print(len(lst_full_combination), lst_full_combination)
        combination_lst_of_tup = self.remove_uncovered_combinations(lst_full_combination)
        lst_final_combination = [list(item) for item in combination_lst_of_tup]

        print('The length of the combination is : {}\n'.format(len(lst_final_combination)))
        print('The Combination list is : {}\n'.format(lst_final_combination))
        return lst_final_combination

    def remove_uncovered_combinations(self, lst_full_combination):
        lst_temp_combination = lst_full_combination.copy()

        for field in self.yaml_n_wise_dct:
            field_values = set(self.yaml_n_wise_dct[field])
            for item in lst_full_combination:
                common_values = set(item).intersection(field_values)
                if len(common_values) > 1 and item in lst_temp_combination:
                    lst_temp_combination.remove(item)
        return lst_temp_combination
