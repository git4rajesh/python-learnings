import yaml
import yamlordereddictloader
from collections import OrderedDict


class InputReader:
    def __init__(self, file_name):
        with open(file_name, 'r') as file_handle:
            self.yaml_full_dct = yaml.load(file_handle, Loader=yamlordereddictloader.Loader)

    def parse_yaml(self, n_wise):
        len_yaml_full_dct = len(self.yaml_full_dct)
        yaml_n_wise_dct = OrderedDict()

        if n_wise < len_yaml_full_dct:  # when n-wise is less than total fields in yaml
            for index, item in enumerate(self.yaml_full_dct):
                if index == n_wise:
                    return yaml_n_wise_dct
                yaml_n_wise_dct[item] = self.yaml_full_dct[item]  # constructing ordered temp dict based on n-wise

        elif n_wise == len_yaml_full_dct:  # when n-wise is equal to the total fields in yaml
            yaml_n_wise_dct = self.yaml_full_dct.copy()
            return yaml_n_wise_dct
        else:
            print('Enter a proper n-wise arguement !!!!')
            exit(1)
