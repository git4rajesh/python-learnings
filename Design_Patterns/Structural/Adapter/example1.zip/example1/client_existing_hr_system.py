class Existing_HR_System:
    def __init__(self):
        self.emp_list_tup = [('Ram', 'Mgr'),
                             ('Raj', 'Engr'),
                             ('Amr', 'CEO'),
                             ('Lak', 'QA')
                             ]
