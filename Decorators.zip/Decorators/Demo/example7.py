def tags(tag_name):
    def tags_decorator(func):
        def func_wrapper(name):
            # print(tag_name)
            # print(name)
            # return func(name)
            return "<{0}>{1}</{0}>".format(tag_name, func(name))

        return func_wrapper

    return tags_decorator


@tags("h1")
def get_text(name):
    return "Hello " + name


print(get_text("John"))
