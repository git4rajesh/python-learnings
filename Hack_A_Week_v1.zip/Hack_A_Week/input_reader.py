import yaml
import yamlordereddictloader
from collections import OrderedDict


class InputReader:
    def __init__(self, file_name):
        with open(file_name, 'r') as file_handle:
            self.yaml_full_dct = yaml.load(file_handle, Loader=yamlordereddictloader.Loader)

    def parse_yaml_old(self, n_wise):
        len_yaml_full_dct = len(self.yaml_full_dct)
        yaml_n_wise_dct = OrderedDict()

        if n_wise < len_yaml_full_dct:  # when n-wise is less than total fields in yaml
            # for index, item in enumerate(self.yaml_full_dct):
            self.compute_length_item()
            # if index == n_wise:
            #     return yaml_n_wise_dct
            # yaml_n_wise_dct[item] = self.yaml_full_dct[item]  # constructing ordered temp dict based on n-wise

        elif n_wise == len_yaml_full_dct:  # when n-wise is equal to the total fields in yaml
            yaml_n_wise_dct = self.yaml_full_dct.copy()
            return yaml_n_wise_dct
        else:
            print('Enter a proper n-wise arguement !!!!')
            exit(1)

    def parse_yaml(self, n_wise):
        len_yaml_full_dct = len(self.yaml_full_dct)
        if n_wise < len_yaml_full_dct:  # when n-wise is less than total fields in yaml
            self.compute_length_item()
            yaml_n_wise_dct = self.get_items_on_len(n_wise)
            return yaml_n_wise_dct
        elif n_wise == len_yaml_full_dct:  # when n-wise is equal to the total fields in yaml
            yaml_n_wise_dct = self.yaml_full_dct.copy()
            return yaml_n_wise_dct
        else:
            print('Enter a proper n-wise arguement !!!!')
            exit(1)

    def compute_length_item(self):
        self.yaml_keys_len = OrderedDict()
        for item in self.yaml_full_dct:
            self.yaml_keys_len[item] = len(self.yaml_full_dct[item])

    def get_items_on_len(self, n_wise):
        temp_len_dct = self.yaml_keys_len.copy()
        yaml_n_wise_dct = {}
        counter = 0
        while counter < n_wise:
            field_with_max_len = max(temp_len_dct, key=temp_len_dct.get)
            yaml_n_wise_dct[field_with_max_len] = self.yaml_full_dct[field_with_max_len]
            del temp_len_dct[field_with_max_len]
            counter += 1
        return yaml_n_wise_dct
