from itertools import chain
from Hack_A_Week.input_reader import InputReader
from Hack_A_Week.combination_generator import CombinationGen


class TestCaseGen:
    def __init__(self, n_wise):
        self.n_wise = n_wise
        self.in_reader_obj = InputReader('data3.yaml')
        self._initializer()

    def _initializer(self):
        self.yaml_n_wise_dct = self.in_reader_obj.parse_yaml(self.n_wise)
        comb_obj = CombinationGen(self.yaml_n_wise_dct)
        self.lst_paired_combination = comb_obj.generate_combination(self.n_wise)
        self.occurence_count = self.get_occurence_count()

    def get_occurence_count(self):
        lst_flattened_combination = list(chain(*self.lst_paired_combination))

        for item in self.yaml_n_wise_dct:
            return lst_flattened_combination.count(self.yaml_n_wise_dct[item][0])

    def distribute_field_values(self):
        yaml_full_dct = self.in_reader_obj.yaml_full_dct

        # Loop through the all yaml file fields
        for index, val in enumerate(yaml_full_dct):

            if index >= self.n_wise:  # Start from fields not considered for n-wise

                outer_index = 0
                combination_temp = []

                # Loop the whole paired combination list generated in batches
                for index in range(self.occurence_count, len(self.lst_paired_combination) + 1, self.occurence_count):
                    field_val_index = 0

                    # Loop until it reaches the batch size
                    while outer_index <= index - 1:
                        # Method to get the appropriate field value and its index
                        field_val, field_val_index = self.get_field_val_index(field_val_index, yaml_full_dct[val],
                                                                              combination_temp,
                                                                              self.lst_paired_combination[outer_index])

                        # Create a temp combination list by adding a new field value
                        combination_temp.append(
                            self.create_temp_lst(self.lst_paired_combination[outer_index], field_val))
                        outer_index += 1
                        field_val_index += 1
                print(combination_temp)
                self.lst_paired_combination = self.flatten_combination_lst(combination_temp)
                print(self.lst_paired_combination)

    def create_temp_lst(self, combination, val):
        lst_combination = list(combination)
        last_elem = lst_combination.pop(-1)
        temp = [last_elem, val]
        lst_combination.append(temp)
        return lst_combination

    def get_field_val_index(self, field_val_index, yaml_field_values, combination_temp, paired_combination):

        # Check if index has reached the end and if so reset to start position
        if field_val_index >= len(yaml_field_values):
            field_val_index = 0
        field_val = yaml_field_values[field_val_index]

        # Check if the incoming temp combination list is not empty
        if combination_temp:
            for item in combination_temp:
                lst_new_combination = []
                lst_new_combination.extend([paired_combination[-1], field_val])

                # Logic to make the distribution Unique
                new_combination = set(lst_new_combination)
                existing_combination = set(item[-1])
                len_existing_combination = len(existing_combination)
                len_intersection_output = len(new_combination.intersection(existing_combination))
                if len_intersection_output == len_existing_combination:
                    field_val_index += 1
                    if field_val_index >= len(yaml_field_values):
                        field_val_index = 0
                    field_val = yaml_field_values[field_val_index]

        return field_val, field_val_index

    # To DO:
    # Can go to helper Class
    # Method to expand the List of Lists
    def flatten_combination_lst(self, combinations):
        temp_combination_lst = []
        for combination in combinations:
            out = list(self.flatten_lst(combination))
            temp_combination_lst.append(out)
        return temp_combination_lst

    def flatten_lst(self, combination):
        for item in combination:
            if type(item) == list:
                for item in self.flatten_lst(item):
                    yield item
            else:
                yield item
